package me.neutron.PLTG;

import android.app.Activity;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout.LayoutParams;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import android.widget.Toast;
import java.util.*;
import me.neutron.PLTG.R;
import me.neutron.PLTG.dataHolder;

public class CourseSelector extends Activity{

    ArrayList<String> list = new ArrayList<String>();
    ArrayList<String> userSelection = new ArrayList<String>();
    ArrayList<Integer> spinnerIds = new ArrayList<Integer>();
    
     ArrayList<String[]> mon = new ArrayList<String[]>();
     ArrayList<String[]> tues = new ArrayList<String[]>();
     ArrayList<String[]> wed = new ArrayList<String[]>();
     ArrayList<String[]> thurs = new ArrayList<String[]>();
     ArrayList<String[]> fri = new ArrayList<String[]>();
     
    int noOfC;
    String name,userSelect;
    
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.course_selector_activity);
       
       //Receiving passed variables and string to int
       Bundle bundle = getIntent().getExtras();
       name = bundle.getString("name");
       String numOfCourse = bundle.getString("noOfC");
       noOfC = Integer.parseInt(numOfCourse);
       
       TextView userName = (TextView)findViewById(R.id.userName);
       userName.setText("Hey "+name+" Select the courses from the dropdown list below");
       
       mon.add(new String[]{"MONDAY","",""});
       tues.add(new String[]{"TUESDAY","",""});
       wed.add(new String[]{"WEDNESDAY","",""});
       thurs.add(new String[]{"THURSDAY","",""});
       fri.add(new String[]{"FRIDAY","",""});
       
       list = getCourseCodes();
       Collections.sort(list);
               
        for(int i=0; i<noOfC; i++){
          genSpinner(i,list);
        }
    }
    
    
    public void genSpinner(int i_d, ArrayList<String> list){
       LinearLayout layout = (LinearLayout)findViewById(R.id.codes);
      //Cr8in Spinner view
      Spinner select = new Spinner(this);
      LinearLayout.LayoutParams params = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
      select.setLayoutParams(params);
      select.setId(i_d);
      layout.addView(select);
      //fill Spinner
      ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,list);
      adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
      select.setAdapter(adapter);
      //get current spinner id
      spinnerIds.add(select.getId());
    }
    
    void getUserSelection(int id){
      Spinner select = (Spinner)findViewById(id);
      //Listener
      String selection = select.getSelectedItem().toString().trim();
      userSelection.add(selection);
      removeDuplicate(userSelection);
    }
    
    void removeDuplicate(ArrayList<String> list){
      Set<String> set = new HashSet<>(list);
      list.clear();
      list.addAll(set);
    }
    
    ArrayList<String> getCourseCodes(){
      dataHolder all_courses = new dataHolder();
      String[][] allCourses = all_courses.items();
      ArrayList<String> dCourses = new ArrayList<String>();
      for(int i=0; i<allCourses.length; i++){
        dCourses.add(allCourses[i][1]);
      }
      removeDuplicate(dCourses);
      return dCourses;
    }
    
    void getCourses(ArrayList<String[]> mon, ArrayList<String[]> tues, ArrayList<String[]> wed, ArrayList<String[]> thurs, ArrayList<String[]> fri, ArrayList<String> userSelection){
      dataHolder all_courses = new dataHolder();
      String[][] allCourses = all_courses.items();
      for(int i=0; i<allCourses.length; i++){
      for(int j=0; j<userSelection.size(); j++){
       if(allCourses[i][1]==userSelection.get(j)){
        if(allCourses[i][0].equals("MONDAY")){
          mon.add(new String[]{allCourses[i][1], allCourses[i][2], allCourses[i][3]});
        }else if(allCourses[i][0].equals("TUESDAY")){
          tues.add(new String[]{allCourses[i][1], allCourses[i][2], allCourses[i][3]});
        }else if(allCourses[i][0].equals("WEDNESDAY")){
          wed.add(new String[]{allCourses[i][1], allCourses[i][2], allCourses[i][3]});
        }else if(allCourses[i][0].equals("THURSDAY")){
          thurs.add(new String[]{allCourses[i][1], allCourses[i][2], allCourses[i][3]});
        }else if(allCourses[i][0].equals("FRIDAY")){
          fri.add(new String[]{allCourses[i][1], allCourses[i][2], allCourses[i][3]});
        }
       }
      }//end for(j)
      }//end for(i)
    }
    
    
    public void toCourseViewer(View v){
      
        for(int i=0; i<spinnerIds.size(); i++){
          getUserSelection(spinnerIds.get(i));
        }
      getCourses(mon,tues,wed,thurs,fri,userSelection);
      
      Intent i = new Intent(this,tTableGenerator.class);
      i.putExtra("name",name);
      i.putExtra("noOfC",noOfC);
      i.putExtra("mon",mon);
      i.putExtra("tues",tues);
      i.putExtra("wed",wed);
      i.putExtra("thurs",thurs);
      i.putExtra("fri",fri);
      startActivity(i);
    }
}