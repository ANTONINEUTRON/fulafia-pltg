package me.neutron.PLTG;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.graphics.Bitmap;
import android.net.Uri;
import android.app.AlertDialog;
import android.graphics.Bitmap.CompressFormat;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import android.util.Log;
import me.neutron.PLTG.R;

public class tTableGenerator extends Activity{
    
    String name;
    int noOfC;
    File file,f;
    
    ArrayList<String[]> mon = new ArrayList<String[]>();
    ArrayList<String[]> tues = new ArrayList<String[]>();
    ArrayList<String[]> wed = new ArrayList<String[]>();
    ArrayList<String[]> thurs = new ArrayList<String[]>();
    ArrayList<String[]> fri = new ArrayList<String[]>();
    
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gen);
        Bundle bundle = getIntent().getExtras();
        name = bundle.getString("name");
        noOfC = bundle.getInt("noOfC");
        mon = (ArrayList<String[]>)bundle.getSerializable("mon");
        tues = (ArrayList<String[]>)bundle.getSerializable("tues");
        wed = (ArrayList<String[]>)bundle.getSerializable("wed");
        thurs = (ArrayList<String[]>)bundle.getSerializable("thurs");
        fri = (ArrayList<String[]>)bundle.getSerializable("fri");
      
      TextView headInfo = (TextView)findViewById(R.id.info);
      headInfo.setText(name+" 2nd Semester Timetable for 2018/2019 Session");
      
      courseShower(mon);
      courseShower(tues);
      courseShower(wed);
      courseShower(thurs);
      courseShower(fri);
      
     }
     
     public void cr8TextView(int id,String item){
       LinearLayout layout = (LinearLayout)findViewById(id);
       TextView tv = new TextView(this);
       tv.setText(item);
       tv.setBackground(getResources().getDrawable(R.drawable.border));
       layout.addView(tv);
     }
     
     public void courseShower(ArrayList<String[]> lister){
       if(lister.get(0)[0].equals("MONDAY")){
         for(int i=1; i<lister.size(); i++){
           cr8TextView(R.id.mon_course, lister.get(i)[0]);
           cr8TextView(R.id.mon_time, lister.get(i)[1]);
           cr8TextView(R.id.mon_venue, lister.get(i)[2]);
         }
       }else if(lister.get(0)[0].equals("TUESDAY")){
         for(int i=1; i<lister.size(); i++){
           cr8TextView(R.id.tues_course, lister.get(i)[0]);
           cr8TextView(R.id.tues_time, lister.get(i)[1]);
           cr8TextView(R.id.tues_venue, lister.get(i)[2]);
         }
       }else if(lister.get(0)[0].equals("WEDNESDAY")){
         for(int i=1; i<lister.size(); i++){
           cr8TextView(R.id.wed_course, lister.get(i)[0]);
           cr8TextView(R.id.wed_time, lister.get(i)[1]);
           cr8TextView(R.id.wed_venue, lister.get(i)[2]);
         }
       }else if(lister.get(0)[0].equals("THURSDAY")){
         for(int i=1; i<lister.size(); i++){
           cr8TextView(R.id.thurs_course, lister.get(i)[0]);
           cr8TextView(R.id.thurs_time, lister.get(i)[1]);
           cr8TextView(R.id.thurs_venue, lister.get(i)[2]);
         }
       }else if(lister.get(0)[0].equals("FRIDAY")){
         for(int i=1; i<lister.size(); i++){
           cr8TextView(R.id.fri_course, lister.get(i)[0]);
           cr8TextView(R.id.fri_time, lister.get(i)[1]);
           cr8TextView(R.id.fri_venue, lister.get(i)[2]);
         }
       }//end if()
     }
     
     public void saveTt(View v){
     
     
     
     try{
       LinearLayout content = (LinearLayout)findViewById(R.id.tShower);
       content.setDrawingCacheEnabled(true);
       Bitmap bitmap = Bitmap.createBitmap(content.getDrawingCache());
       if(android.os.Environment.getExternalStorageState().equals(android.os.Environment.MEDIA_MOUNTED)){
         file = new File(android.os.Environment.getExternalStorageDirectory(),"FULafia Timetable");
         if(!file.exists()){
           file.mkdirs();
         }
         f = new File(file.getAbsolutePath()+file.separator+name+" 2nd Semester Timetable"+".jpg");
       }
       FileOutputStream ostream = new FileOutputStream(f);
       bitmap.compress(CompressFormat.JPEG,100,ostream);
       ostream.close();
       Intent intent = new
       Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
       intent.setData(Uri.fromFile(f));
       sendBroadcast(intent);
         Toast.makeText(getApplicationContext(),"The Timetable has been Saved! Check Your GALLERY To View it", Toast.LENGTH_LONG).show();
       }catch(Exception e){
         messageBox("Err",e.getMessage());
       }
     }
     
     public void messageBox(String method, String message){
      Log.d("Exception: "+method, message);
      AlertDialog.Builder messageBox = new AlertDialog.Builder(this);
      messageBox.setTitle(method);
      messageBox.setMessage(message);
      messageBox.setCancelable(false);
      messageBox.setNeutralButton("Ok",null);
      messageBox.show();
    }
     
}
