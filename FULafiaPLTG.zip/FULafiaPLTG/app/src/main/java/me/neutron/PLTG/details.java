package me.neutron.PLTG;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.Toast;
import android.view.View;
import android.content.Intent;
import me.neutron.PLTG.R;

public class details extends Activity{
    
    String numOfCourse;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        setContentView(R.layout.details_activity);
        Spinner num = (Spinner)findViewById(R.id.courses);
        String[] items = {"1","2","3","4","5","6","7","8","9","10","11","12","13","14"};
        
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,items);
        
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        num.setAdapter(adapter);
       
       //Set listener
        num.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
          @Override
          public void onItemSelected(AdapterView<?> parent,View view,int position,long id){
            numOfCourse = parent.getItemAtPosition(position).toString();
         //numOfCourse to be use in  next activity
          }
          @Override
          public void onNothingSelected(AdapterView<?> arg0){
           //TODO - Custom Code
          }
        });
    }
    
    public void courseSelector(View v){
       EditText edit = (EditText)findViewById(R.id.name);
       String name = edit.getText().toString();
       if(name.length() < 4){
         Toast.makeText(getApplicationContext(),"Please Input a valid name!", Toast.LENGTH_LONG).show();
       }else{
         Intent i = new Intent(this,CourseSelector.class);
         i.putExtra("name",name);
         i.putExtra("noOfC",numOfCourse);
         startActivity(i);
       }
    }
    
}
